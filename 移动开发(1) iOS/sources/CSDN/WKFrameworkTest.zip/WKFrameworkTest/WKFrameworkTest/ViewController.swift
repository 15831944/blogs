//
//  ViewController.swift
//  WKFrameworkTest
//
//  Created by Addison on 14-8-17.
//  Copyright (c) 2014年 Addison. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIWebViewDelegate {
                            
    @IBOutlet weak var address: UITextField!
    @IBOutlet weak var web: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let URL = NSURL.URLWithString("http://chenfeng.info/zc2/button.html")
        let request = NSURLRequest(URL: URL);
        web.loadRequest(request)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func brower(sender: AnyObject) {
        var url = "";
        if address.text.isEmpty{
            return;
        }
        if !address.text.hasPrefix("http://"){
            url = "http://"+address.text
        }
        
        let URL = NSURL.URLWithString(url)
        let request = NSURLRequest(URL: URL);
        web.loadRequest(request)
    }
    
    func webView(webView: UIWebView!, shouldStartLoadWithRequest request: NSURLRequest!, navigationType: UIWebViewNavigationType) -> Bool{
        println("收到消息")
        let url = request.URL
        if (url.scheme == "ios") {
            var fun = url.host
            var arg0 = url.query
            println("方法名为："+fun)
            println("参数为:"+arg0)
            return false;
        }
        return true;
    }

}

