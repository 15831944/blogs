//
//  WKViewController.swift
//  WKFrameworkTest
//
//  Created by Addison on 14-8-17.
//  Copyright (c) 2014年 Addison. All rights reserved.
//

import UIKit
import WebKit


class WKViewController: UIViewController,WKScriptMessageHandler {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let config = WKWebViewConfiguration()
        let scriptHandle = WKUserContentController()
        scriptHandle.addScriptMessageHandler(self, name: "test")
        
        let per = WKPreferences()
        per.javaScriptCanOpenWindowsAutomatically = true
        per.javaScriptEnabled = true
        config.preferences = per
        config.userContentController = scriptHandle
        
        let web = WKWebView(frame: CGRectMake(20, 20, 300, 600),configuration: config)
        self.view.addSubview(web)
        let url = NSURL.URLWithString("http://chenfeng.info/zc2/button.html")
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue!, sender: AnyObject!) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func userContentController(userContentController: WKUserContentController!, didReceiveScriptMessage message: WKScriptMessage!){
        println("收到消息")
        var fun = message.name
        var arg0 = message.body as String
        println("方法名为："+fun)
        println("参数为:"+arg0)
    }

}
