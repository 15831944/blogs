//
//  LeftViewController.swift
//  xQQ
//
//  Created by 方武显 on 15/3/9.
//  Copyright (c) 2015年 小五哥Swift教程. All rights reserved.
//

import UIKit
class LeftViewController: UIViewController {
    
}
