//
//  MessageViewController.swift
//  xQQ
//
//  Created by 方武显 on 15/3/9.
//  Copyright (c) 2015年 小五哥Swift教程. All rights reserved.
//

import UIKit
class MessageViewController: UIViewController {
    //
    override func viewDidLoad()
    {
        super.viewDidLoad()
        //左侧显示头像
        var photoView:UIImageView=UIImageView(image: UIImage(named: "AppIcon-160x60@2x.png"))
        photoView.frame=CGRectMake(0, 0, 30, 30)
        var photoItem:UIBarButtonItem=UIBarButtonItem(customView: photoView)
        self.navigationItem.leftBarButtonItem=photoItem
        //头像变圆形(设弧度为宽度的一半)
        photoView.clipsToBounds=true
        photoView.layer.cornerRadius=photoView.bounds.width*0.5
        //设置titleView为
        var titleSegment=UISegmentedControl(items: ["消息", "电话"])
        titleSegment.selectedSegmentIndex=0
        self.navigationItem.titleView=titleSegment
        //右侧一按钮
        var rightButton:UIButton=UIButton()
        rightButton.frame=CGRect(origin:CGPointZero, size: CGSize(width: 26, height: 26))
        rightButton.setBackgroundImage(UIImage(named: "menu_icon_bulb.png"), forState: UIControlState.Normal);
        var rightItem:UIBarButtonItem=UIBarButtonItem(customView: rightButton)
        self.navigationItem.rightBarButtonItem=rightItem
        //
        self.navigationController?.tabBarItem.selectedImage=UIImage(named: "tab_recent_press.png")
    }
    
  
}
