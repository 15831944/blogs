//
//  SliderViewController.swift
//  xQQ
//
//  Created by 方武显 on 15/3/9.
//  Copyright (c) 2015年 小五哥Swift教程. All rights reserved.
//

import UIKit
class SliderViewController: UIViewController {
    
    var mainContentView:UIView!
    var leftSideView:UIView!
    var rightSideView:UIView!

    override func viewDidLoad() {
        super.viewDidLoad();
        initSubViews()
       // showLeftViewController()
    }
    //在self.View上添加左中右三个视图
    func initSubViews()
    {
        let viewRect=self.view.bounds        
        rightSideView=UIView(frame:viewRect)
        rightSideView.backgroundColor=UIColor.blueColor()
        self.view.addSubview(rightSideView)
        leftSideView=UIView(frame:viewRect)
        leftSideView.backgroundColor=UIColor.yellowColor()
        self.view.addSubview(leftSideView)
        mainContentView=UIView(frame:viewRect)
        mainContentView.backgroundColor=UIColor.redColor()
        self.view.addSubview(mainContentView)
        //用mainContentView装下MainTab
        var mainTabVC: UITabBarController! = self.storyboard!.instantiateViewControllerWithIdentifier("MainTabViewController") as UITabBarController

        mainContentView.addSubview(mainTabVC.view)
    }
    
    //显示主要内容
    func showContentController(className:NSString)
    {
    }
    //显示左侧Controller
    func showLeftViewController()
    {
        let translateX:CGFloat=200
        let transcale:CGFloat=0.85
        var transT:CGAffineTransform=CGAffineTransformMakeTranslation(translateX, 0)
        var scaleT:CGAffineTransform=CGAffineTransformMakeScale(transcale, transcale)
        var conT:CGAffineTransform=CGAffineTransformConcat(transT, scaleT)
        UIView.animateWithDuration(0.8, animations: { () -> Void in
            self.mainContentView.transform=conT
        })
    }
    //显示右侧Controller
    func showRightViewController()
    {
    
    }
    //隐藏侧栏
    func closeSiderBar()
    {
    
    }
}
