//
//  ViewController.swift
//  xQQ
//
//  Created by 方武显 on 15/3/8.
//  Copyright (c) 2015年 小五哥Swift教程. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

